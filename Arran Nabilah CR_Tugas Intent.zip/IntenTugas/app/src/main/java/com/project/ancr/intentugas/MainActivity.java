package com.project.ancr.intentugas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    public static final String EXTRA_MESSAGE = "com.project.ancr.extra.MESSAGE";
    private EditText mMessageEditTextNama,
                     mMessageEditTextAlamat,
                     mMessageEditTextNotlp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMessageEditTextNama = (EditText) findViewById(R.id.editText_nama);
        mMessageEditTextAlamat = (EditText) findViewById(R.id.editText_alamat);
        mMessageEditTextNama = (EditText) findViewById(R.id.editText_nama);
        mMessageEditTextNotlp = (EditText) findViewById(R.id.editText_notelp);


    }

    public void verification(View view) {

        Log.d(LOG_TAG, "Register Berhasil!");
        Intent intent = new Intent(this, verification.class);
        String message1 = mMessageEditTextNama.getText().toString();
        String message2 = mMessageEditTextAlamat.getText().toString();
        String message3 = mMessageEditTextNotlp.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "Nama : "+message1+"\n Alamat  : "+message2+"\n No.Telepon : "+message3);
        startActivity(intent);
    }
}
